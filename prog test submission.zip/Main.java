
import java.util.Random;
import java.util.Arrays;
public class Main {
    public static void main(String[] args) {
        //initialize
        String[] strArr = new String[50];

        String[] strArr;
        strArr = new String[50];
        for (int i = strArr.length - 1; i >= 0; i--) {
            System.out.println(i + ":" + strArr[i]);
        }
        // add random array
        Random rand = new Random();
        int[] intArr = new int[50];
        for (int i = 0; i < intArr.length; i++) {
            intArr[i] = rand.nextInt(50);
        }
        int[][] intArr = new int[5][8];
        int[][] intArr;
        intArr = new int[5][8];

        int[][] intArr;
        intArr = new int[5][];
        intArr[0] = new int[8];
        intArr[1] = new int[8];
        intArr[2] = new int[8];
        intArr[3] = new int[8];
        intArr[4] = new int[8]
        for (int row = 0; row < intArr.length; row++) {
            for (int col = 0; col < intArr[row].length; col++) {
                intArr[row][col] =


                for (int[] row : intArr) {
                    for (int i = 0; i < row.length; i++) {
                        if (i > 0) {
                            //display the array
                        }
                        System.out.print(" ");
                    }
                    System.out.print(row[i]);
                }
                System.out.println();
            }


        }
    }
}
